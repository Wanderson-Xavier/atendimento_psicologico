package com.atendimento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtendimentoPsicologicoApplicationTests {

	@Test
	void contextLoads() {
	}

}

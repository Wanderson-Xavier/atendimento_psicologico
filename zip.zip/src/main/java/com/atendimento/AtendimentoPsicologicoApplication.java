package com.atendimento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtendimentoPsicologicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtendimentoPsicologicoApplication.class, args);
	}

}
